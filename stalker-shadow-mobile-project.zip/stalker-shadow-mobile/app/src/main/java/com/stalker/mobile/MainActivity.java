package com.stalker.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import android.view.MotionEvent;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(new GameView());
    }

    class GameView extends View {
        Paint p = new Paint(3);
        Random random = new Random();
        float playerX=0, playerY=0, aimX=0, aimY=0;
        boolean moving=false, firing=false;
        int health=100, ammo=30, kills=0;
        long lastShot=0;
        ArrayList<Enemy> enemies = new ArrayList<>();
        String message="SECTOR 01  |  FIND THE STALKER";
        class Enemy { float x,y; int hp=2; Enemy(float a,float b){x=a;y=b;} }
        GameView(){ super(MainActivity.this); setFocusable(true); for(int i=0;i<4;i++) spawn(); }
        void spawn(){ enemies.add(new Enemy((random.nextFloat()-.5f)*1.4f, 1.5f+random.nextFloat()*1.5f)); }
        void color(int c){ p.setColor(c); p.setStyle(Paint.Style.FILL); }
        void text(Canvas c,String s,float x,float y,float size,int col){
            p.setTypeface(android.graphics.Typeface.create("sans-serif-condensed",android.graphics.Typeface.BOLD));
            p.setTextSize(size); p.setColor(col); c.drawText(s,x,y,p);
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight();
            // Lightweight pseudo-3D outdoor scene
            c.drawColor(Color.rgb(48,62,48));
            color(Color.rgb(70,82,62)); c.drawRect(0,0,w,h*.48f,p);
            color(Color.rgb(45,48,38)); c.drawRect(0,h*.48f,w,h,p);
            p.setColor(Color.rgb(87,83,65));
            c.drawPath(path(w,h),p);
            // distant ruined buildings / tree silhouettes
            for(int i=0;i<9;i++){
                float bx=(i*w/9f), bh=h*(.12f+(i%3)*.035f);
                color(i%2==0?Color.rgb(36,42,37):Color.rgb(52,55,47));
                c.drawRect(bx,h*.42f-bh,bx+w*.055f,h*.49f,p);
                color(Color.rgb(24,30,26)); c.drawRect(bx+w*.012f,h*.38f-bh,bx+w*.025f,h*.43f,p);
            }
            // ground perspective lines
            p.setColor(Color.argb(75,190,180,140)); p.setStrokeWidth(2);
            for(int i=0;i<8;i++){ float yy=h*.52f+i*i*h*.006f; c.drawLine(w*.5f,h*.49f,w*(i/7f),yy,p); }
            // enemies drawn with depth scaling
            for(Enemy e:enemies){
                float depth=Math.max(.25f,e.y), scale=Math.min(1.5f,1.0f/depth);
                float ex=w*(.5f+e.x/depth*.38f), ey=h*(.48f+1.0f/depth*.17f);
                float sz=h*.11f*scale;
                color(Color.rgb(25,30,26)); c.drawOval(ex-sz*.35f,ey-sz,ex+sz*.35f,ey-sz*.25f,p);
                color(Color.rgb(65,74,62)); c.drawRoundRect(ex-sz*.45f,ey-sz*.25f,ex+sz*.45f,ey+sz*.65f,sz*.15f,sz*.15f,p);
                color(Color.rgb(40,45,39)); c.drawRect(ex-sz*.35f,ey+sz*.55f,ex-sz*.08f,ey+sz*1.1f,p); c.drawRect(ex+sz*.08f,ey+sz*.55f,ex+sz*.35f,ey+sz*1.1f,p);
                color(Color.rgb(180,45,35)); c.drawCircle(ex,ey-sz*.58f,sz*.06f,p);
            }
            // weapon silhouette
            color(Color.rgb(20,22,20)); c.drawRoundRect(w*.42f,h*.78f,w*.58f,h*1.08f,18,18,p);
            color(Color.rgb(70,72,65)); c.drawRect(w*.47f,h*.72f,w*.53f,h*.9f,p);
            color(Color.rgb(30,32,29)); c.drawRect(w*.49f,h*.63f,w*.51f,h*.79f,p);
            // crosshair
            p.setColor(Color.argb(220,210,210,190)); p.setStrokeWidth(2);
            c.drawLine(w*.5f-18,h*.5f,w*.5f-6,h*.5f,p); c.drawLine(w*.5f+6,h*.5f,w*.5f+18,h*.5f,p);
            c.drawLine(w*.5f,h*.5f-18,w*.5f,h*.5f-6,p); c.drawLine(w*.5f,h*.5f+6,w*.5f,h*.5f+18,p);
            // vignette-like top/bottom bands and HUD
            color(Color.argb(190,10,13,11)); c.drawRect(0,0,w,h*.12f,p); c.drawRect(0,h*.88f,w,h,p);
            text(c,"S.T.A.L.K.E.R.  //  SHADOW MOBILE",w*.025f,h*.075f,h*.035f,Color.rgb(210,205,170));
            text(c,"HEALTH "+health+"%",w*.025f,h*.94f,h*.032f,health<30?Color.RED:Color.rgb(190,210,180));
            text(c,"AK-74  |  "+ammo+"/30",w*.72f,h*.94f,h*.032f,Color.rgb(220,210,180));
            text(c,"KILLS "+kills,w*.88f,h*.075f,h*.03f,Color.rgb(210,205,170));
            // touch controls
            p.setColor(Color.argb(65,230,230,220)); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(3);
            c.drawCircle(w*.13f,h*.77f,h*.09f,p); c.drawCircle(w*.13f,h*.77f,h*.035f,p);
            p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(110,180,180,170)); c.drawRoundRect(w*.82f,h*.68f,w*.96f,h*.86f,24,24,p);
            text(c,"FIRE",w*.855f,h*.785f,h*.035f,Color.WHITE);
            text(c,message,w*.35f,h*.16f,h*.03f,Color.rgb(190,190,165));
            // simple movement and enemy advance
            if(moving){ playerX+=.008f; for(Enemy e:enemies)e.x-=.003f; }
            if(firing && System.currentTimeMillis()-lastShot>260){
                lastShot=System.currentTimeMillis(); if(ammo>0){ ammo--; shoot(); } else message="RELOAD: TAP RELOAD";
            }
            invalidate();
        }
        android.graphics.Path path(float w,float h){
            android.graphics.Path q=new android.graphics.Path(); q.moveTo(0,h*.47f); q.lineTo(w*.42f,h*.49f); q.lineTo(w*.58f,h*.49f); q.lineTo(w,h*.47f); q.lineTo(w,h); q.lineTo(0,h); q.close(); return q;
        }
        void shoot(){
            Enemy target=null; float best=Float.MAX_VALUE;
            for(Enemy e:enemies){ float score=Math.abs(e.x)+e.y*.08f; if(score<best){best=score;target=e;} }
            if(target!=null && Math.abs(target.x)<.35f && target.y<2.8f){
                target.hp--; if(target.hp<=0){enemies.remove(target);kills++;spawn();message="TARGET DOWN";} else message="HIT";
            } else message="MISS";
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
                if(x<w*.28f && y>h*.58f){moving=true;}
                else if(x>w*.78f && y>h*.6f){firing=true;}
                else { aimX=x; aimY=y; }
                return true;
            }
            if(e.getAction()==MotionEvent.ACTION_UP){moving=false;firing=false;
                if(x>w*.65f && y>h*.88f){ammo=30;message="RELOADED";}
                return true;
            }
            return true;
        }
    }
}
