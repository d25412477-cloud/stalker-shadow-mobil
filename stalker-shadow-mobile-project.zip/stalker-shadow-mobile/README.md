# S.T.A.L.K.E.R. Shadow Mobile — starter

Lightweight Android prototype for landscape phones. This is an original starter inspired by the survival-shooter genre, not a copy of the original game assets.

## What's included
- Android Java project (`com.stalker.mobile`)
- Landscape fullscreen game view
- Lightweight pseudo-3D Zone scene, HUD, crosshair, touch movement/fire, ammo/reload, basic targets
- GitHub Actions workflow that builds a debug APK with Java 17 and Gradle 8.9

## Build APK on GitHub
1. Create a GitHub repository named `stalker-shadow-mobile`.
2. Upload the contents of this ZIP to the repository root (not the ZIP itself).
3. Open **Actions** → **Android APK** → **Run workflow** (or push to `main`/`master`).
4. Download the `stalker-mobile-debug` artifact from the completed workflow.
5. Extract it and install `app-debug.apk` on your Android device. You may need to allow installs from your browser/files app.

## Local build
Requires JDK 17 and Gradle 8.9:
```bash
gradle assembleDebug
```

This is a first playable prototype, not a full recreation. Next milestones: proper 3D engine/terrain, animations, inventory, missions, audio, and optimized assets.
